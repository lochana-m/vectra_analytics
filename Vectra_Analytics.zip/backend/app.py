from flask import Flask
from flask_cors import CORS
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from auth_routes import auth_bp
from data_routes import data_bp
from analytics_routes import analytics_bp
from forecast_routes import forecast_bp
from chatbot_routes import chatbot_bp
from report_routes import report_bp
from upload_routes import upload_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'vectra_secret_key_2024_secure'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

CORS(app, resources={r"/*": {"origins": "*"}})

app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(data_bp, url_prefix='/api/data')
app.register_blueprint(analytics_bp, url_prefix='/api/analytics')
app.register_blueprint(forecast_bp, url_prefix='/api/forecast')
app.register_blueprint(chatbot_bp, url_prefix='/api/chatbot')
app.register_blueprint(report_bp, url_prefix='/api/report')
app.register_blueprint(upload_bp, url_prefix='/api/upload')

@app.route('/api/health')
def health():
    return {'status': 'ok', 'message': 'Backend is running'}

if __name__ == '__main__':
    print("=" * 60)
    print("  VECTRA ANALYTICS BACKEND")
    print("  Running on http://localhost:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
