import bcrypt
import jwt
import datetime
import uuid

SECRET_KEY = 'vectra_secret_key_2024_secure'

users_db = {}
reset_tokens = {}

def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def generate_token(email):
    payload = {
        'email': email,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24),
        'iat': datetime.datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def verify_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return payload
    except:
        return None

def generate_reset_token():
    return str(uuid.uuid4())

def create_user(email, password, name):
    if email in users_db:
        return None, "Email already registered"
    users_db[email] = {
        'email': email,
        'name': name,
        'password': hash_password(password),
        'created_at': datetime.datetime.utcnow().isoformat()
    }
    return users_db[email], None

def get_user(email):
    return users_db.get(email)

def update_password(email, new_password):
    if email in users_db:
        users_db[email]['password'] = hash_password(new_password)
        return True
    return False
