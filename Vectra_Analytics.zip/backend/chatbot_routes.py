from flask import Blueprint, request, jsonify
from database import verify_token
from ml_engine import (
    prepare_time_series, run_arima_forecast, detect_anomalies,
    compute_growth_metrics, compute_product_comparison,
    compute_financial_analysis, compute_operations_analysis, simulate_scenario
)
from data_manager import get_products, get_available_datasets
import numpy as np
import re

chatbot_bp = Blueprint('chatbot', __name__)

# Track conversation state per session
_chat_context = {}

def require_auth():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        payload = verify_token(auth_header[7:])
        if payload:
            return payload
    return None

def extract_intent(query):
    """Extract intent using keyword matching (lightweight NLP)"""
    q = query.lower().strip()
    intents = {
        'forecast': ['forecast', 'predict', 'future', 'next month', 'next period', 'projection', 'outlook', 'what will', 'expected'],
        'anomaly': ['anomaly', 'anomalies', 'spike', 'drop', 'unusual', 'outlier', 'abnormal', 'strange', 'weird'],
        'growth': ['growth', 'grew', 'growth rate', 'trend', 'increasing', 'decreasing', 'how much', 'performance'],
        'product': ['product', 'best product', 'top product', 'worst product', 'compare product', 'which product'],
        'financial': ['revenue', 'cost', 'profit', 'margin', 'financial', 'income', 'expense', 'cash flow', 'risk'],
        'operations': ['operations', 'bottleneck', 'efficiency', 'optimize', 'timing', 'peak day', 'slow day'],
        'recommendation': ['recommend', 'suggestion', 'advice', 'what should', 'improve', 'strategy', 'optimize'],
        'scenario': ['scenario', 'what if', 'simulate', 'if we increase', 'if we decrease', 'hypothetical'],
        'summary': ['summary', 'overview', 'total', 'overall', 'big picture', 'dashboard', 'how is'],
        'help': ['help', 'what can', 'capabilities', 'features']
    }

    scores = {}
    for intent, keywords in intents.items():
        score = sum(1 for kw in keywords if kw in q)
        if score > 0:
            scores[intent] = score

    if scores:
        return max(scores, key=scores.get)
    return 'general'

def extract_product(query, dataset):
    """Try to extract product name from query"""
    products = get_products(dataset)
    q = query.lower()
    for product in products:
        if product.lower() in q:
            return product
    return 'All'

def extract_number(query):
    """Extract a number from query for scenario simulation"""
    numbers = re.findall(r'[-+]?\d+\.?\d*', query)
    if numbers:
        return float(numbers[0])
    return 10  # default

def build_response(intent, dataset, query):
    """Build contextual response using computed data"""
    product = extract_product(query, dataset)

    if intent == 'forecast':
        ts = prepare_time_series(dataset, product=product, period='month')
        if ts is not None and 'sales' in ts.columns:
            forecast, order, _ = run_arima_forecast(ts['sales'], steps=3)
            metrics = compute_growth_metrics(ts['sales'])
            avg_f = round(float(np.mean(forecast)), 2)
            latest = metrics.get('latest', 0)
            change = round((avg_f - latest) / latest * 100, 2) if latest != 0 else 0
            return (
                f"Based on the ARIMA({order[0]},{order[1]},{order[2]}) model trained on historical data, "
                f"the forecast for {'**' + product + '**' if product != 'All' else 'all products'} projects an average of **${avg_f:,}** "
                f"over the next 3 months. This represents a **{change}%** {'increase' if change > 0 else 'decrease'} from the most recent period. "
                f"The model trend direction is **{metrics.get('trend_direction', 'neutral')}** with an R² of {metrics.get('r_squared', 0)}. "
                f"Seasonal patterns and historical volatility (CV: {metrics.get('coefficient_of_variation', 0)}%) were factored into the projection."
            )
        return "Insufficient historical data to generate a reliable forecast. Please ensure the dataset has at least 12 months of data."

    elif intent == 'anomaly':
        ts = prepare_time_series(dataset, product=product, period='month')
        if ts is not None and 'sales' in ts.columns:
            anomalies = detect_anomalies(ts['sales'])
            if anomalies:
                latest = anomalies[-1]
                return (
                    f"Anomaly detection identified **{len(anomalies)} anomalies** in the data for {'**' + product + '**' if product != 'All' else 'all products'}. "
                    f"The most recent anomaly occurred on **{latest['date']}** — a **{latest['type']}** with a value of **${latest['value']:,}** "
                    f"(Z-score: {latest['z_score']}). The historical mean is ${latest['mean']:,}, so this represents a **{latest['deviation_pct']}%** deviation. "
                    f"Possible causes include seasonal promotions, supply chain disruptions, or market-wide events."
                )
            return f"No statistically significant anomalies detected in the current dataset for {'**' + product + '**' if product != 'All' else 'all products'}. The data shows consistent patterns within normal variance."
        return "Unable to perform anomaly analysis. Please check the dataset."

    elif intent == 'growth':
        ts = prepare_time_series(dataset, product=product, period='month')
        if ts is not None and 'sales' in ts.columns:
            metrics = compute_growth_metrics(ts['sales'])
            return (
                f"**Growth Analysis** for {'**' + product + '**' if product != 'All' else 'all products'}:\n\n"
                f"- **Period-over-Period Growth:** {metrics.get('growth_rate', 0)}%\n"
                f"- **Half-Period Trend Change:** {metrics.get('trend_change', 0)}%\n"
                f"- **Overall Trend:** {metrics.get('trend_direction', 'neutral').capitalize()} (slope: {metrics.get('trend_slope', 0)})\n"
                f"- **Total Revenue:** ${metrics.get('total', 0):,}\n"
                f"- **Volatility (CV):** {metrics.get('coefficient_of_variation', 0)}%\n\n"
                f"The {metrics.get('trend_direction', 'neutral')} trend is {'statistically significant' if metrics.get('p_value', 1) < 0.05 else 'not yet statistically significant'} (p={metrics.get('p_value', 0)})."
            )
        return "Growth data is not available for this selection."

    elif intent == 'product':
        comparisons = compute_product_comparison(dataset)
        if comparisons:
            top = comparisons[0]
            bottom = comparisons[-1]
            return (
                f"**Product Performance Breakdown** ({len(comparisons)} products):\n\n"
                f"- **Top Performer:** {top['product']} — ${ top['total_sales']:,} total sales, {top['margin_pct']}% profit margin\n"
                f"- **Lowest Performer:** {bottom['product']} — ${bottom['total_sales']:,} total sales, {bottom['margin_pct']}% profit margin\n\n"
                f"The gap between the top and bottom performers is **${top['total_sales'] - bottom['total_sales']:,}** in total sales. "
                f"Top performer trend is **{top['trend']}** while bottom is **{bottom['trend']}**. "
                f"Consider reallocating marketing resources toward {bottom['product']} if the market potential supports it."
            )
        return "Product comparison data is not available."

    elif intent == 'financial':
        fin = compute_financial_analysis(dataset, product=product)
        if fin and 'risk_metrics' in fin:
            risk = fin['risk_metrics']
            return (
                f"**Financial Health Report:**\n\n"
                f"- **Risk Level:** {risk['risk_level']}\n"
                f"- **Profit Volatility:** ${risk['volatility']:,}\n"
                f"- **Mean Profit (Monthly):** ${risk['mean_profit']:,}\n"
                f"- **Value at Risk (95% confidence):** ${risk['var_95']:,}\n"
                f"- **Max Drawdown:** ${risk['max_drawdown']:,}\n\n"
                f"The Sharpe-like ratio of {risk['sharpe_like_ratio']} {'indicates healthy risk-adjusted returns' if risk['sharpe_like_ratio'] > 1 else 'suggests elevated risk relative to returns'}. "
                f"{'Consider diversification strategies to reduce exposure.' if risk['risk_level'] == 'High' else 'Current financial metrics are within acceptable parameters.'}"
            )
        return "Financial analysis requires both sales and cost data in the dataset."

    elif intent == 'operations':
        ops = compute_operations_analysis(dataset)
        if ops:
            suggestions = ops.get('suggestions', [])
            return (
                f"**Operations Analysis:**\n\n"
                f"- **Bottleneck Days Detected:** {ops.get('bottleneck_count', 0)}\n"
                f"- **Peak Days Detected:** {ops.get('peak_count', 0)}\n"
                f"- **Avg Daily Transactions:** {ops.get('mean_daily_transactions', 0)}\n\n"
                f"**Recommendations:**\n" + "\n".join(f"- {s}" for s in suggestions)
            )
        return "Operations analysis data is not available."

    elif intent == 'scenario':
        change = extract_number(query)
        result = simulate_scenario(dataset, product, change, periods=3)
        if result:
            return (
                f"**Scenario Simulation** ({'+' if change > 0 else ''}{change}% change for {'**' + product + '**' if product != 'All' else 'all products'}):\n\n"
                f"- **Baseline Forecast (3 months):** ${result['total_baseline']:,}\n"
                f"- **Adjusted Forecast:** ${result['total_adjusted']:,}\n"
                f"- **Net Impact:** {'+'if result['impact'] > 0 else ''}${result['impact']:,}\n\n"
                f"This simulation applies a {change}% adjustment to the ARIMA model baseline. "
                f"{'The projected increase would require sustained operational support.' if change > 0 else 'A decline of this magnitude may impact cash flow projections.'}"
            )
        return "Unable to run scenario simulation with the current data."

    elif intent == 'recommendation':
        ts = prepare_time_series(dataset, product=product, period='month')
        metrics = compute_growth_metrics(ts['sales']) if ts is not None and 'sales' in ts.columns else {}
        comparisons = compute_product_comparison(dataset)

        recs = []
        if metrics.get('growth_rate', 0) < 0:
            recs.append("Sales are declining. Investigate seasonal factors and consider promotional campaigns.")
        if metrics.get('coefficient_of_variation', 0) > 40:
            recs.append("High volatility detected. Implement demand smoothing strategies and diversify product lines.")
        if comparisons:
            low_margin = [p for p in comparisons if p['margin_pct'] < 20]
            if low_margin:
                recs.append(f"Products {', '.join(p['product'] for p in low_margin[:3])} have low margins. Review pricing or cost reduction.")
        if not recs:
            recs.append("Current metrics are healthy. Maintain existing strategies and monitor for seasonal shifts.")

        return "**Strategic Recommendations based on data analysis:**\n\n" + "\n".join(f"- {r}" for r in recs)

    elif intent == 'summary':
        ts = prepare_time_series(dataset, product=product, period='month')
        if ts is not None and 'sales' in ts.columns:
            metrics = compute_growth_metrics(ts['sales'])
            return (
                f"**Dashboard Summary:**\n\n"
                f"- **Total Sales:** ${metrics.get('total', 0):,}\n"
                f"- **Average Monthly Sales:** ${metrics.get('average', 0):,}\n"
                f"- **Latest Period:** ${metrics.get('latest', 0):,}\n"
                f"- **Growth Rate:** {metrics.get('growth_rate', 0)}%\n"
                f"- **Trend:** {metrics.get('trend_direction', 'neutral').capitalize()}\n"
                f"- **Data Range:** {metrics.get('min_value', 0):,} — {metrics.get('max_value', 0):,}"
            )
        return "Summary data could not be retrieved."

    elif intent == 'help':
        return (
            "**I can help you with:**\n\n"
            "- **Forecasting:** Ask about future sales predictions\n"
            "- **Anomalies:** Ask about unusual spikes or drops\n"
            "- **Growth:** Ask about trends and growth rates\n"
            "- **Products:** Ask to compare product performance\n"
            "- **Financial:** Ask about revenue, costs, profit, or risk\n"
            "- **Operations:** Ask about efficiency or bottlenecks\n"
            "- **Scenarios:** Try 'what if sales increase by 20%'\n"
            "- **Recommendations:** Ask for strategic suggestions\n"
            "- **Summary:** Ask for an overall data overview"
        )

    else:
        # General fallback: provide summary
        ts = prepare_time_series(dataset, product=product, period='month')
        if ts is not None and 'sales' in ts.columns:
            metrics = compute_growth_metrics(ts['sales'])
            return (
                f"Here's a quick overview of your data: Total sales stand at **${metrics.get('total', 0):,}** "
                f"with a {metrics.get('trend_direction', 'neutral')} trend ({metrics.get('growth_rate', 0)}% recent growth). "
                f"Feel free to ask about forecasts, anomalies, products, financial health, or recommendations — "
                f"I can analyze all of these using your current dataset."
            )
        return "I'm ready to help analyze your data. Try asking about forecasts, growth trends, product comparison, or financial health."

@chatbot_bp.route('/query', methods=['POST'])
def chatbot_query():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    data = request.get_json()
    query = data.get('query', '').strip()
    dataset = data.get('dataset', 'uk_ecommerce')

    if not query:
        return jsonify({'success': False, 'message': 'Query is required'}), 400

    intent = extract_intent(query)
    response = build_response(intent, dataset, query)

    return jsonify({
        'success': True,
        'response': response,
        'intent': intent,
        'dataset': dataset
    })
