from flask import Blueprint, request, jsonify
from database import verify_token
from data_manager import detect_columns, register_uploaded_dataset, get_quality_report
import pandas as pd
import io
import os

upload_bp = Blueprint('upload', __name__)

def require_auth():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        payload = verify_token(auth_header[7:])
        if payload:
            return payload
    return None

@upload_bp.route('/upload', methods=['POST'])
def upload_dataset():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file provided'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400

    if not file.filename.lower().endswith('.csv'):
        return jsonify({'success': False, 'message': 'Only CSV files are supported'}), 400

    try:
        # Read CSV
        content = file.read()
        df = pd.read_csv(io.BytesIO(content))

        if df.empty:
            return jsonify({'success': False, 'message': 'CSV file is empty'}), 400

        if len(df.columns) < 2:
            return jsonify({'success': False, 'message': 'CSV must have at least 2 columns'}), 400

        # Generate dataset name
        base_name = os.path.splitext(file.filename)[0].lower().replace(' ', '_').replace('-', '_')
        # Remove non-alphanumeric except underscore
        import re
        dataset_name = re.sub(r'[^a-z0-9_]', '', base_name)
        if not dataset_name:
            dataset_name = 'custom_dataset'

        # Detect columns
        column_info = detect_columns(df)

        # Generate quality report
        quality_report = get_quality_report(df)

        # Register dataset
        register_uploaded_dataset(dataset_name, df)

        return jsonify({
            'success': True,
            'message': f'Dataset uploaded successfully: {len(df)} rows, {len(df.columns)} columns',
            'dataset_name': dataset_name,
            'columns': df.columns.tolist(),
            'column_detection': column_info,
            'quality_report': quality_report,
            'preview': df.head(5).to_dict('records'),
            'shape': {'rows': len(df), 'columns': len(df.columns)}
        })

    except Exception as e:
        return jsonify({'success': False, 'message': f'Upload failed: {str(e)}'}), 500

@upload_bp.route('/validate', methods=['POST'])
def validate_dataset():
    """Validate a CSV without fully uploading"""
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file provided'}), 400

    file = request.files['file']

    try:
        content = file.read()
        df = pd.read_csv(io.BytesIO(content))

        column_info = detect_columns(df)
        quality_report = get_quality_report(df)

        return jsonify({
            'success': True,
            'valid': True,
            'rows': len(df),
            'columns': df.columns.tolist(),
            'column_detection': column_info,
            'quality_report': quality_report,
            'preview': df.head(3).to_dict('records')
        })

    except Exception as e:
        return jsonify({'success': True, 'valid': False, 'error': str(e)}), 200
