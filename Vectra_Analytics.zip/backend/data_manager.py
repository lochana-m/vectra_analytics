import pandas as pd
import numpy as np
import os
import re
from datetime import datetime

DATA_DIR = os.path.join(os.path.dirname(__file__), 'datasets')

# In-memory cache
_dataset_cache = {}
_uploaded_datasets = {}
_column_mappings = {}  # For user-confirmed mappings

DEMO_DATASETS = ['uk_ecommerce', 'walmart', 'rossmann']

def get_available_datasets():
    datasets = list(DEMO_DATASETS)
    datasets.extend(list(_uploaded_datasets.keys()))
    return datasets

def generate_uk_ecommerce():
    """Generate realistic UK Ecommerce dataset"""
    np.random.seed(42)
    dates = pd.date_range(start='2023-01-01', end='2024-12-31', freq='D')
    products = ['Laptop', 'Smartphone', 'Tablet', 'Headphones', 'Smartwatch',
                'Keyboard', 'Monitor', 'Webcam', 'Mouse', 'Speaker']
    records = []
    base_prices = {'Laptop': 1200, 'Smartphone': 850, 'Tablet': 550, 'Headphones': 180,
                   'Smartwatch': 320, 'Keyboard': 95, 'Monitor': 450, 'Webcam': 110,
                   'Mouse': 65, 'Speaker': 230}
    for date in dates:
        for product in products:
            base = base_prices[product]
            # Seasonal pattern: higher in Nov-Dec
            season_factor = 1.0
            if date.month in [11, 12]:
                season_factor = 1.6
            elif date.month in [6, 7]:
                season_factor = 0.85
            # Weekly pattern
            if date.weekday() in [4, 5]:  # Fri, Sat
                week_factor = 1.25
            else:
                week_factor = 1.0
            quantity = max(1, int(np.random.poisson(lam=3 * season_factor * week_factor)))
            unit_price = round(base * (1 + np.random.normal(0, 0.08)), 2)
            sales = round(unit_price * quantity, 2)
            cost = round(unit_price * quantity * np.random.uniform(0.55, 0.72), 2)
            records.append({
                'Date': date.strftime('%Y-%m-%d'),
                'Product': product,
                'Quantity': quantity,
                'UnitPrice': unit_price,
                'Sales': sales,
                'Cost': cost,
                'Region': np.random.choice(['London', 'Manchester', 'Birmingham', 'Edinburgh', 'Bristol'])
            })
    return pd.DataFrame(records)

def generate_walmart():
    """Generate realistic Walmart-style dataset"""
    np.random.seed(123)
    dates = pd.date_range(start='2022-06-01', end='2024-11-30', freq='D')
    products = ['Electronics', 'Groceries', 'Clothing', 'Furniture', 'Sports',
                'Toys', 'Beauty', 'Pharmacy', 'Books', 'Automotive']
    records = []
    base_sales = {'Electronics': 4500, 'Groceries': 8200, 'Clothing': 3100, 'Furniture': 2800,
                  'Sports': 1900, 'Toys': 1400, 'Beauty': 2100, 'Pharmacy': 3600,
                  'Books': 950, 'Automotive': 1700}
    for date in dates:
        for product in products:
            base = base_sales[product]
            trend = 1 + 0.0003 * (date - dates[0]).days  # Slight upward trend
            season = 1.0
            if date.month in [11, 12]:
                season = 1.7 if product in ['Electronics', 'Toys', 'Clothing'] else 1.3
            elif date.month in [1, 2]:
                season = 0.75
            noise = np.random.normal(1, 0.12)
            sales = round(max(50, base * trend * season * noise), 2)
            cost = round(sales * np.random.uniform(0.6, 0.75), 2)
            quantity = max(1, int(sales / np.random.uniform(20, 100)))
            records.append({
                'Date': date.strftime('%Y-%m-%d'),
                'Product': product,
                'Quantity': quantity,
                'Sales': sales,
                'Cost': cost,
                'Store': f'Store_{np.random.randint(1, 50)}'
            })
    return pd.DataFrame(records)

def generate_rossmann():
    """Generate realistic Rossmann-style drugstore dataset"""
    np.random.seed(77)
    dates = pd.date_range(start='2023-03-01', end='2024-10-31', freq='D')
    products = ['Vitamins', 'Skincare', 'Haircare', 'OTC Medicine', 'Dental Care',
                'Baby Products', 'Cleaning Supplies', 'Perfume', 'Eye Care', 'Supplements']
    records = []
    base_sales = {'Vitamins': 320, 'Skincare': 580, 'Haircare': 420, 'OTC Medicine': 750,
                  'Dental Care': 280, 'Baby Products': 390, 'Cleaning Supplies': 510,
                  'Perfume': 460, 'Eye Care': 190, 'Supplements': 350}
    for date in dates:
        for product in products:
            base = base_sales[product]
            # Flu season boost for OTC Medicine
            if product == 'OTC Medicine' and date.month in [12, 1, 2, 3]:
                season = 1.8
            elif product in ['Skincare', 'Perfume'] and date.month in [3, 4, 12]:
                season = 1.5  # Spring/Gift season
            elif product == 'Baby Products' and date.month in [8, 9]:
                season = 1.4  # Back to school adjacent
            else:
                season = 1.0 + 0.1 * np.sin(2 * np.pi * date.timetuple().tm_yday / 365)
            # Inject anomalies for anomaly detection
            anomaly = 1.0
            if date.day == 15 and date.month in [3, 7, 10]:
                anomaly = 2.5  # Promotional spike
            sales = round(max(10, base * season * anomaly * np.random.normal(1, 0.1)), 2)
            cost = round(sales * np.random.uniform(0.58, 0.7), 2)
            quantity = max(1, int(sales / np.random.uniform(5, 30)))
            records.append({
                'Date': date.strftime('%Y-%m-%d'),
                'Product': product,
                'Quantity': quantity,
                'Sales': sales,
                'Cost': cost,
                'StoreID': np.random.randint(100, 200)
            })
    return pd.DataFrame(records)

_generators = {
    'uk_ecommerce': generate_uk_ecommerce,
    'walmart': generate_walmart,
    'rossmann': generate_rossmann
}

def load_dataset(name):
    """Load and cache a dataset by name"""
    if name in _dataset_cache:
        return _dataset_cache[name].copy()

    if name in _uploaded_datasets:
        df = _uploaded_datasets[name].copy()
        _dataset_cache[name] = df
        return df.copy()

    if name in _generators:
        df = _generators[name]()
        _dataset_cache[name] = df
        return df.copy()

    return None

def register_uploaded_dataset(name, df):
    """Register an uploaded dataset"""
    _uploaded_datasets[name] = df
    _dataset_cache[name] = df
    return True

def detect_columns(df):
    """Auto-detect date, sales, and product columns with validation"""
    cols = df.columns.tolist()
    date_col = None
    sales_col = None
    product_col = None
    cost_col = None
    quantity_col = None

    date_keywords = ['date', 'datetime', 'time', 'timestamp', 'day', 'period']
    sales_keywords = ['sales', 'revenue', 'amount', 'total', 'price', 'sales_amount']
    product_keywords = ['product', 'item', 'category', 'name', 'product_name', 'item_id']
    cost_keywords = ['cost', 'expense', 'cogs']
    qty_keywords = ['quantity', 'qty', 'units', 'count']

    # Detect date column
    for col in cols:
        lower = col.lower().strip()
        if not date_col and any(kw in lower for kw in date_keywords):
            # Validate it's actually a date
            try:
                pd.to_datetime(df[col].iloc[:5], errors='coerce')
                date_col = col
            except:
                continue

    # Detect sales column (must be numeric)
    for col in cols:
        lower = col.lower().strip()
        if not sales_col and any(kw in lower for kw in sales_keywords):
            # Validate it's numeric
            if pd.api.types.is_numeric_dtype(df[col]) or df[col].dtype == 'object':
                try:
                    # Try to convert to numeric
                    pd.to_numeric(df[col].iloc[:10], errors='raise')
                    sales_col = col
                except:
                    continue
    
    # If no keyword match for sales, find the first numeric column
    if not sales_col:
        for col in cols:
            if pd.api.types.is_numeric_dtype(df[col]):
                try:
                    # Make sure it has reasonable values
                    test_vals = pd.to_numeric(df[col].iloc[:10], errors='coerce').dropna()
                    if len(test_vals) > 0 and test_vals.mean() > 0:
                        sales_col = col
                        break
                except:
                    continue

    # Detect product column
    for col in cols:
        lower = col.lower().strip()
        if not product_col and any(kw in lower for kw in product_keywords):
            # Should be text/categorical
            if df[col].dtype == 'object' or pd.api.types.is_categorical_dtype(df[col]):
                product_col = col

    # Detect cost column (must be numeric)
    for col in cols:
        lower = col.lower().strip()
        if not cost_col and any(kw in lower for kw in cost_keywords):
            if pd.api.types.is_numeric_dtype(df[col]):
                cost_col = col

    # Detect quantity column (must be numeric)
    for col in cols:
        lower = col.lower().strip()
        if not quantity_col and any(kw in lower for kw in qty_keywords):
            if pd.api.types.is_numeric_dtype(df[col]):
                quantity_col = col

    # Confidence check
    confidence = sum([1 for x in [date_col, sales_col, product_col] if x is not None])
    needs_confirmation = confidence < 2  # At least date and sales required

    return {
        'date_col': date_col,
        'sales_col': sales_col,
        'product_col': product_col,
        'cost_col': cost_col,
        'quantity_col': quantity_col,
        'needs_confirmation': needs_confirmation,
        'all_columns': cols
    }

def set_column_mapping(dataset_name, mapping):
    """Set user-confirmed column mapping"""
    _column_mappings[dataset_name] = mapping

def get_column_mapping(dataset_name):
    """Get column mapping for dataset (user confirmed or auto-detected)"""
    if dataset_name in _column_mappings:
        return _column_mappings[dataset_name]
    df = load_dataset(dataset_name)
    if df is not None:
        return detect_columns(df)
    return None

def get_products(dataset_name):
    """Get unique products from dataset"""
    df = load_dataset(dataset_name)
    if df is None:
        return []
    mapping = get_column_mapping(dataset_name)
    if mapping and mapping.get('product_col'):
        return sorted(df[mapping['product_col']].unique().tolist())
    return []

def get_filtered_data(dataset_name, product=None, period='month', start_date=None, end_date=None):
    """Get filtered and aggregated data for a dataset"""
    df = load_dataset(dataset_name)
    if df is None:
        return None

    mapping = get_column_mapping(dataset_name)
    if not mapping:
        return None

    date_col = mapping['date_col']
    sales_col = mapping['sales_col']
    product_col = mapping['product_col']
    cost_col = mapping.get('cost_col')

    # Parse dates
    if date_col:
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        df = df.dropna(subset=[date_col])

    # VALIDATION: Ensure sales column is numeric
    if sales_col:
        df[sales_col] = pd.to_numeric(df[sales_col], errors='coerce')
        df = df.dropna(subset=[sales_col])

    # Filter by product
    if product and product != 'All' and product_col:
        df = df[df[product_col] == product]

    # Filter by date range
    if start_date:
        df = df[df[date_col] >= pd.to_datetime(start_date)]
    if end_date:
        df = df[df[date_col] <= pd.to_datetime(end_date)]

    # Aggregate by period
    df = df.set_index(date_col)
    if period == 'day':
        agg_df = df.resample('D')
    elif period == 'week':
        agg_df = df.resample('W')
    elif period == 'month':
        agg_df = df.resample('MS')
    elif period == 'year':
        agg_df = df.resample('YS')
    else:
        agg_df = df.resample('MS')

    result = {}
    if sales_col and sales_col in df.columns:
        result['sales'] = agg_df[sales_col].sum()
    if cost_col and cost_col in df.columns:
        # Ensure cost is also numeric
        df[cost_col] = pd.to_numeric(df[cost_col], errors='coerce')
        result['cost'] = agg_df[cost_col].sum()

    return result

def get_quality_report(df):
    """Generate data quality report"""
    total_rows = len(df)
    total_cols = len(df.columns)

    missing = {}
    for col in df.columns:
        m = df[col].isna().sum()
        if m > 0:
            missing[col] = {'count': int(m), 'percentage': round(m / total_rows * 100, 2)}

    duplicates = int(df.duplicated().sum())

    outliers = {}
    for col in df.select_dtypes(include=[np.number]).columns:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        outlier_count = int(((df[col] < lower) | (df[col] > upper)).sum())
        if outlier_count > 0:
            outliers[col] = {'count': outlier_count, 'percentage': round(outlier_count / total_rows * 100, 2)}

    return {
        'total_rows': total_rows,
        'total_columns': total_cols,
        'missing_values': missing,
        'duplicate_rows': duplicates,
        'outliers': outliers,
        'completeness_score': round((1 - sum(v['count'] for v in missing.values()) / (total_rows * total_cols)) * 100, 2) if total_rows > 0 else 0
    }
