import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

def prepare_time_series(dataset_name, product=None, period='month'):
    """Prepare a clean time series for ML models"""
    from data_manager import load_dataset, get_column_mapping

    df = load_dataset(dataset_name)
    if df is None:
        return None

    mapping = get_column_mapping(dataset_name)
    if not mapping:
        return None

    date_col = mapping['date_col']
    sales_col = mapping['sales_col']
    product_col = mapping.get('product_col')
    cost_col = mapping.get('cost_col')

    if date_col:
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        df = df.dropna(subset=[date_col])

    # VALIDATION: Ensure numeric columns
    if sales_col:
        df[sales_col] = pd.to_numeric(df[sales_col], errors='coerce')
        df = df.dropna(subset=[sales_col])
    
    if cost_col and cost_col in df.columns:
        df[cost_col] = pd.to_numeric(df[cost_col], errors='coerce')

    if product and product != 'All' and product_col and product_col in df.columns:
        df = df[df[product_col] == product]

    df = df.set_index(date_col)

    if period == 'day':
        freq = 'D'
    elif period == 'week':
        freq = 'W'
    elif period == 'month':
        freq = 'MS'
    elif period == 'year':
        freq = 'YS'
    else:
        freq = 'MS'

    agg = {}
    if sales_col and sales_col in df.columns:
        agg['sales'] = df[sales_col].resample(freq).sum()
    if cost_col and cost_col in df.columns:
        agg['cost'] = df[cost_col].resample(freq).sum()

    return pd.DataFrame(agg).dropna()

def run_arima_forecast(series, steps=6, order=None):
    """Run ARIMA model and return forecast - OPTIMIZED for speed"""
    if len(series) < 12:
        # Use Exponential Smoothing for short series
        return run_ets_forecast(series, steps)

    if order is None:
        # OPTIMIZED: Use faster default order instead of grid search
        # Grid search is too slow for real-time dashboards
        order = (1, 1, 1)  # Simple ARIMA(1,1,1) works well for most business data

    try:
        model = ARIMA(series.values, order=order)
        result = model.fit()
        forecast = result.forecast(steps=steps)
        return forecast, order, result
    except Exception as e:
        # Fallback to even simpler model
        try:
            model = ARIMA(series.values, order=(0, 1, 0))
            result = model.fit()
            forecast = result.forecast(steps=steps)
            return forecast, (0, 1, 0), result
        except:
            return run_ets_forecast(series, steps)

def run_ets_forecast(series, steps=6):
    """Exponential Smoothing fallback - OPTIMIZED"""
    try:
        # OPTIMIZED: Skip seasonal component for speed
        model = ExponentialSmoothing(series.values, trend='add')
        result = model.fit()
        forecast = result.forecast(steps)
        return forecast, (1, 1, 1), result
    except:
        # Simple linear forecast as last resort
        x = np.arange(len(series))
        slope, intercept, _, _, _ = stats.linregress(x, series.values)
        future_x = np.arange(len(series), len(series) + steps)
        forecast = slope * future_x + intercept
        return forecast, (0, 1, 0), None

def detect_anomalies(series, threshold=2.5):
    """Detect anomalies using Z-score method"""
    if len(series) < 5:
        return []

    values = series.values.astype(float)
    mean = np.mean(values)
    std = np.std(values)

    if std == 0:
        return []

    z_scores = np.abs((values - mean) / std)
    anomaly_indices = np.where(z_scores > threshold)[0]

    # Also use IQR method for robustness
    q1 = np.percentile(values, 25)
    q3 = np.percentile(values, 75)
    iqr = q3 - q1
    iqr_lower = q1 - 1.5 * iqr
    iqr_upper = q3 + 1.5 * iqr
    iqr_anomalies = np.where((values < iqr_lower) | (values > iqr_upper))[0]

    # Union of both methods
    all_anomalies = sorted(set(anomaly_indices.tolist() + iqr_anomalies.tolist()))

    anomalies = []
    for idx in all_anomalies:
        direction = 'spike' if values[idx] > mean else 'drop'
        deviation_pct = round(((values[idx] - mean) / mean) * 100, 2) if mean != 0 else 0
        anomalies.append({
            'index': int(idx),
            'date': series.index[idx].strftime('%Y-%m-%d') if hasattr(series.index[idx], 'strftime') else str(series.index[idx]),
            'value': round(float(values[idx]), 2),
            'mean': round(float(mean), 2),
            'z_score': round(float(z_scores[idx]), 2),
            'type': direction,
            'deviation_pct': deviation_pct,
            'explanation': f"{'Spike' if direction == 'spike' else 'Drop'} detected: value {deviation_pct}% {'above' if direction == 'spike' else 'below'} the historical mean. Z-score: {round(float(z_scores[idx]), 2)}. This represents a statistically significant deviation (>{threshold} std devs) from the normal pattern."
        })

    return anomalies

def compute_growth_metrics(series):
    """Compute growth and statistical metrics from a time series"""
    if len(series) < 2:
        return {}

    values = series.values.astype(float)
    total = float(np.sum(values))
    avg = float(np.mean(values))
    latest = float(values[-1])
    previous = float(values[-2])
    growth_rate = round(((latest - previous) / previous * 100), 2) if previous != 0 else 0

    # Period-over-period comparison (first half vs second half)
    mid = len(values) // 2
    first_half_avg = float(np.mean(values[:mid]))
    second_half_avg = float(np.mean(values[mid:]))
    trend_change = round(((second_half_avg - first_half_avg) / first_half_avg * 100), 2) if first_half_avg != 0 else 0

    # Trend direction using linear regression
    x = np.arange(len(values))
    slope, intercept, r_value, p_value, std_err = stats.linregress(x, values)

    return {
        'total': round(total, 2),
        'average': round(avg, 2),
        'latest': round(latest, 2),
        'previous': round(previous, 2),
        'growth_rate': growth_rate,
        'trend_change': trend_change,
        'trend_slope': round(float(slope), 4),
        'trend_direction': 'upward' if slope > 0 else 'downward',
        'r_squared': round(float(r_value ** 2), 4),
        'p_value': round(float(p_value), 6),
        'std_deviation': round(float(np.std(values)), 2),
        'min_value': round(float(np.min(values)), 2),
        'max_value': round(float(np.max(values)), 2),
        'coefficient_of_variation': round(float(np.std(values) / np.mean(values) * 100), 2) if np.mean(values) != 0 else 0
    }

def compute_product_comparison(dataset_name):
    """Compute metrics for all products"""
    from data_manager import load_dataset, get_column_mapping, get_products

    df = load_dataset(dataset_name)
    if df is None:
        return []

    mapping = get_column_mapping(dataset_name)
    product_col = mapping.get('product_col')
    sales_col = mapping.get('sales_col')
    cost_col = mapping.get('cost_col')
    date_col = mapping.get('date_col')

    if not product_col or not sales_col:
        return []

    products = get_products(dataset_name)
    results = []

    for product in products:
        pdf = df[df[product_col] == product]
        total_sales = round(float(pdf[sales_col].sum()), 2)
        avg_sales = round(float(pdf[sales_col].mean()), 2)
        total_cost = round(float(pdf[cost_col].sum()), 2) if cost_col and cost_col in pdf.columns else 0
        profit = round(total_sales - total_cost, 2)
        margin = round((profit / total_sales * 100), 2) if total_sales != 0 else 0

        # Monthly trend
        if date_col:
            pdf_indexed = pdf.copy()
            pdf_indexed[date_col] = pd.to_datetime(pdf_indexed[date_col])
            pdf_indexed = pdf_indexed.set_index(date_col)
            monthly = pdf_indexed[sales_col].resample('MS').sum()
            if len(monthly) >= 2:
                x = np.arange(len(monthly))
                slope, _, _, _, _ = stats.linregress(x, monthly.values)
                trend = 'up' if slope > 0 else 'down'
            else:
                trend = 'stable'
        else:
            trend = 'stable'

        results.append({
            'product': product,
            'total_sales': total_sales,
            'average_sales': avg_sales,
            'total_cost': total_cost,
            'profit': profit,
            'margin_pct': margin,
            'trend': trend,
            'transaction_count': len(pdf)
        })

    results.sort(key=lambda x: x['total_sales'], reverse=True)
    return results

def simulate_scenario(dataset_name, product, change_pct, periods=6):
    """Simulate scenario: what if sales change by X%"""
    ts = prepare_time_series(dataset_name, product=product, period='month')
    if ts is None or 'sales' not in ts.columns:
        return None

    sales_series = ts['sales']
    forecast, order, _ = run_arima_forecast(sales_series, steps=periods)

    # Apply change
    adjusted_forecast = np.array(forecast) * (1 + change_pct / 100)

    # Generate future dates
    last_date = sales_series.index[-1]
    future_dates = pd.date_range(start=last_date, periods=periods + 1, freq='MS')[1:]

    return {
        'baseline_forecast': [round(float(v), 2) for v in forecast],
        'adjusted_forecast': [round(float(v), 2) for v in adjusted_forecast],
        'dates': [d.strftime('%Y-%m-%d') for d in future_dates],
        'change_pct': change_pct,
        'total_baseline': round(float(np.sum(forecast)), 2),
        'total_adjusted': round(float(np.sum(adjusted_forecast)), 2),
        'impact': round(float(np.sum(adjusted_forecast) - np.sum(forecast)), 2)
    }

def compute_financial_analysis(dataset_name, product=None):
    """Full financial analysis: revenue, cost, profit, cash flow, risk"""
    ts = prepare_time_series(dataset_name, product=product, period='month')
    if ts is None:
        return None

    result = {}
    if 'sales' in ts.columns:
        result['revenue'] = ts['sales'].tolist()
        result['revenue_dates'] = [d.strftime('%Y-%m-%d') for d in ts.index]

    if 'cost' in ts.columns:
        result['cost'] = ts['cost'].tolist()

    if 'sales' in ts.columns and 'cost' in ts.columns:
        profit = (ts['sales'] - ts['cost'])
        result['profit'] = profit.tolist()
        result['profit_margin'] = [(p / s * 100 if s != 0 else 0) for p, s in zip(profit, ts['sales'])]

        # Cash flow (cumulative profit)
        result['cash_flow'] = profit.cumsum().tolist()

        # Risk metrics using volatility
        profit_values = profit.values.astype(float)
        if len(profit_values) > 1:
            volatility = float(np.std(profit_values))
            mean_profit = float(np.mean(profit_values))
            # Value at Risk (VaR) - 95% confidence
            var_95 = float(np.percentile(profit_values, 5))
            result['risk_metrics'] = {
                'volatility': round(volatility, 2),
                'mean_profit': round(mean_profit, 2),
                'var_95': round(var_95, 2),
                'sharpe_like_ratio': round(mean_profit / volatility, 4) if volatility != 0 else 0,
                'max_drawdown': round(float(np.min(profit_values)), 2),
                'risk_level': 'High' if volatility > mean_profit * 0.5 else 'Medium' if volatility > mean_profit * 0.25 else 'Low'
            }

        # Forecast future revenue
        if len(ts['sales']) >= 6:
            rev_forecast, _, _ = run_arima_forecast(ts['sales'], steps=6)
            result['revenue_forecast'] = [round(float(v), 2) for v in rev_forecast]

    return result

def compute_operations_analysis(dataset_name):
    """Analyze transaction timing and volume patterns"""
    from data_manager import load_dataset, get_column_mapping

    df = load_dataset(dataset_name)
    if df is None:
        return None

    mapping = get_column_mapping(dataset_name)
    date_col = mapping.get('date_col')
    sales_col = mapping.get('sales_col')
    product_col = mapping.get('product_col')

    if not date_col:
        return None

    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    df = df.dropna(subset=[date_col])

    # Day-of-week analysis
    df['dow'] = df[date_col].dt.dayofweek
    dow_analysis = df.groupby('dow').agg(
        total_sales=(sales_col, 'sum'),
        avg_sales=(sales_col, 'mean'),
        transaction_count=(sales_col, 'count')
    ).reset_index()
    dow_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    dow_analysis['day_name'] = dow_analysis['dow'].map(lambda x: dow_names[x])

    # Month-of-year analysis
    df['month'] = df[date_col].dt.month
    month_analysis = df.groupby('month').agg(
        total_sales=(sales_col, 'sum'),
        avg_sales=(sales_col, 'mean'),
        transaction_count=(sales_col, 'count')
    ).reset_index()

    # Bottleneck detection: days with unusually low transaction volume
    daily_counts = df.groupby(df[date_col].dt.date)[sales_col].count()
    mean_count = daily_counts.mean()
    std_count = daily_counts.std()
    bottleneck_days = daily_counts[daily_counts < mean_count - 1.5 * std_count]

    # Peak detection
    peak_days = daily_counts[daily_counts > mean_count + 1.5 * std_count]

    suggestions = []
    # Analyze patterns for suggestions
    dow_totals = dow_analysis.set_index('dow')['total_sales']
    lowest_day = dow_totals.idxmin()
    highest_day = dow_totals.idxmax()
    suggestions.append(f"{dow_names[lowest_day]} shows the lowest transaction volume. Consider targeted promotions or marketing campaigns on this day to boost engagement.")
    suggestions.append(f"{dow_names[highest_day]} is the peak day. Ensure adequate staffing and inventory to meet demand.")

    if len(bottleneck_days) > 0:
        suggestions.append(f"Detected {len(bottleneck_days)} bottleneck days with significantly below-average activity. Review operational efficiency on these dates.")

    return {
        'day_of_week': dow_analysis.to_dict('records'),
        'monthly_distribution': month_analysis.to_dict('records'),
        'bottleneck_count': len(bottleneck_days),
        'peak_count': len(peak_days),
        'mean_daily_transactions': round(float(mean_count), 2),
        'std_daily_transactions': round(float(std_count), 2),
        'suggestions': suggestions
    }
