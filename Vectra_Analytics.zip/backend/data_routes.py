from flask import Blueprint, request, jsonify
from database import verify_token
from data_manager import (
    get_available_datasets, load_dataset, get_products,
    get_filtered_data, detect_columns, set_column_mapping, get_column_mapping
)

data_bp = Blueprint('data', __name__)

def require_auth():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        payload = verify_token(auth_header[7:])
        if payload:
            return payload
    return None

@data_bp.route('/datasets', methods=['GET'])
def list_datasets():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    return jsonify({'success': True, 'datasets': get_available_datasets()})

@data_bp.route('/products', methods=['GET'])
def get_product_list():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    dataset = request.args.get('dataset', 'uk_ecommerce')
    products = get_products(dataset)
    return jsonify({'success': True, 'products': products})

@data_bp.route('/detect-columns', methods=['GET'])
def detect_dataset_columns():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    dataset = request.args.get('dataset')
    if not dataset:
        return jsonify({'success': False, 'message': 'Dataset name required'}), 400
    df = load_dataset(dataset)
    if df is None:
        return jsonify({'success': False, 'message': 'Dataset not found'}), 404
    result = detect_columns(df)
    return jsonify({'success': True, **result})

@data_bp.route('/confirm-mapping', methods=['POST'])
def confirm_mapping():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    data = request.get_json()
    dataset = data.get('dataset')
    mapping = data.get('mapping')
    if not dataset or not mapping:
        return jsonify({'success': False, 'message': 'Dataset and mapping required'}), 400
    set_column_mapping(dataset, mapping)
    return jsonify({'success': True, 'message': 'Column mapping confirmed'})

@data_bp.route('/filtered', methods=['GET'])
def get_filtered():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    product = request.args.get('product', 'All')
    period = request.args.get('period', 'month')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')

    result = get_filtered_data(dataset, product=product, period=period, start_date=start_date, end_date=end_date)
    if result is None:
        return jsonify({'success': False, 'message': 'Failed to retrieve data'}), 500

    response_data = {}
    for key, series in result.items():
        response_data[key] = {
            'dates': [d.strftime('%Y-%m-%d') for d in series.index],
            'values': [round(float(v), 2) for v in series.values]
        }

    return jsonify({'success': True, 'data': response_data, 'period': period})

@data_bp.route('/summary', methods=['GET'])
def get_summary():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    product = request.args.get('product', 'All')

    from ml_engine import prepare_time_series, compute_growth_metrics
    ts = prepare_time_series(dataset, product=product, period='month')
    if ts is None or 'sales' not in ts.columns:
        return jsonify({'success': False, 'message': 'No data'}), 500

    metrics = compute_growth_metrics(ts['sales'])
    return jsonify({'success': True, 'metrics': metrics})

@data_bp.route('/product-distribution', methods=['GET'])
def get_product_distribution():
    """Returns sales distribution by product for donut chart"""
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    from data_manager import load_dataset as ld, get_column_mapping as gcm
    import pandas as pd

    df = ld(dataset)
    if df is None:
        return jsonify({'success': False, 'message': 'Dataset not found'}), 404

    mapping = gcm(dataset)
    product_col = mapping.get('product_col')
    sales_col = mapping.get('sales_col')

    if not product_col or not sales_col:
        return jsonify({'success': False, 'message': 'Columns not available'}), 500

    # VALIDATION: Ensure sales is numeric
    df[sales_col] = pd.to_numeric(df[sales_col], errors='coerce')
    df = df.dropna(subset=[sales_col])

    dist = df.groupby(product_col)[sales_col].sum().reset_index()
    dist = dist.sort_values(sales_col, ascending=False)

    return jsonify({
        'success': True,
        'labels': dist[product_col].tolist(),
        'values': [round(float(v), 2) for v in dist[sales_col].values]
    })

@data_bp.route('/last-7-days', methods=['GET'])
def get_last_7_days():
    """Returns sales for last 7 days relative to dataset"""
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    from data_manager import load_dataset as ld, get_column_mapping as gcm
    import pandas as pd

    df = ld(dataset)
    if df is None:
        return jsonify({'success': False, 'message': 'Dataset not found'}), 404

    mapping = gcm(dataset)
    date_col = mapping.get('date_col')
    sales_col = mapping.get('sales_col')

    if not date_col or not sales_col:
        return jsonify({'success': False}), 500

    df[date_col] = pd.to_datetime(df[date_col])
    max_date = df[date_col].max()

    days_data = []
    for i in range(7):
        target_date = max_date - pd.Timedelta(days=i)
        day_df = df[df[date_col].dt.date == target_date.date()]
        total = round(float(day_df[sales_col].sum()), 2)
        days_data.append({
            'label': f'Day-{i+1}',
            'date': target_date.strftime('%Y-%m-%d'),
            'sales': total
        })

    days_data.reverse()
    return jsonify({'success': True, 'data': days_data})
