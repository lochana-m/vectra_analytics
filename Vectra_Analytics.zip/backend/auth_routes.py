from flask import Blueprint, request, jsonify
from database import (
    create_user, get_user, verify_password, generate_token,
    verify_token, generate_reset_token, reset_tokens, update_password
)
import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    name = data.get('name', '').strip()

    if not email or not password or not name:
        return jsonify({'success': False, 'message': 'All fields are required'}), 400
    if len(password) < 6:
        return jsonify({'success': False, 'message': 'Password must be at least 6 characters'}), 400
    if '@' not in email:
        return jsonify({'success': False, 'message': 'Invalid email format'}), 400

    user, err = create_user(email, password, name)
    if err:
        return jsonify({'success': False, 'message': err}), 409

    token = generate_token(email)
    return jsonify({
        'success': True,
        'message': 'Account created successfully',
        'token': token,
        'user': {'email': email, 'name': name}
    })

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'success': False, 'message': 'Email and password required'}), 400

    user = get_user(email)
    if not user:
        return jsonify({'success': False, 'message': 'Invalid email or password'}), 401

    if not verify_password(password, user['password']):
        return jsonify({'success': False, 'message': 'Invalid email or password'}), 401

    token = generate_token(email)
    return jsonify({
        'success': True,
        'message': 'Login successful',
        'token': token,
        'user': {'email': email, 'name': user['name']}
    })

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    data = request.get_json()
    email = data.get('email', '').strip().lower()

    if not email:
        return jsonify({'success': False, 'message': 'Email required'}), 400

    user = get_user(email)
    if not user:
        # Don't reveal if user exists or not
        return jsonify({'success': True, 'message': 'If this email is registered, you will receive a reset link.'})

    token = generate_reset_token()
    reset_tokens[token] = {
        'email': email,
        'expires_at': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }

    # In production, send email. For demo, return token in response.
    return jsonify({
        'success': True,
        'message': 'Password reset link sent successfully.',
        'reset_token': token  # In production this would be emailed
    })

@auth_bp.route('/reset-password', methods=['POST'])
def reset_password():
    data = request.get_json()
    token = data.get('token', '')
    new_password = data.get('password', '')

    if not token or not new_password:
        return jsonify({'success': False, 'message': 'Token and new password required'}), 400

    if len(new_password) < 6:
        return jsonify({'success': False, 'message': 'Password must be at least 6 characters'}), 400

    if token not in reset_tokens:
        return jsonify({'success': False, 'message': 'Invalid or expired reset token'}), 400

    reset_data = reset_tokens[token]
    if datetime.datetime.utcnow() > reset_data['expires_at']:
        del reset_tokens[token]
        return jsonify({'success': False, 'message': 'Reset token has expired'}), 400

    email = reset_data['email']
    if update_password(email, new_password):
        del reset_tokens[token]
        return jsonify({'success': True, 'message': 'Password reset successfully'})

    return jsonify({'success': False, 'message': 'Failed to update password'}), 500

@auth_bp.route('/verify', methods=['GET'])
def verify():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        token = auth_header[7:]
        payload = verify_token(token)
        if payload:
            user = get_user(payload['email'])
            if user:
                return jsonify({'success': True, 'user': {'email': user['email'], 'name': user['name']}})
    return jsonify({'success': False, 'message': 'Invalid or expired token'}), 401
