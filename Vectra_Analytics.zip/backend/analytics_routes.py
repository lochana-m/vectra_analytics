from flask import Blueprint, request, jsonify
from database import verify_token
from ml_engine import (
    compute_growth_metrics, compute_product_comparison,
    compute_financial_analysis, compute_operations_analysis,
    prepare_time_series, detect_anomalies
)

analytics_bp = Blueprint('analytics', __name__)

def require_auth():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        payload = verify_token(auth_header[7:])
        if payload:
            return payload
    return None

@analytics_bp.route('/growth', methods=['GET'])
def growth_metrics():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    product = request.args.get('product', 'All')
    period = request.args.get('period', 'month')

    ts = prepare_time_series(dataset, product=product, period=period)
    if ts is None or 'sales' not in ts.columns:
        return jsonify({'success': False, 'message': 'No data available'}), 500

    metrics = compute_growth_metrics(ts['sales'])
    return jsonify({'success': True, 'metrics': metrics})

@analytics_bp.route('/product-comparison', methods=['GET'])
def product_comparison():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    results = compute_product_comparison(dataset)
    return jsonify({'success': True, 'products': results})

@analytics_bp.route('/financial', methods=['GET'])
def financial_analysis():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    product = request.args.get('product', 'All')

    result = compute_financial_analysis(dataset, product=product)
    if result is None:
        return jsonify({'success': False, 'message': 'Financial analysis failed'}), 500

    return jsonify({'success': True, 'data': result})

@analytics_bp.route('/operations', methods=['GET'])
def operations_analysis():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    result = compute_operations_analysis(dataset)
    if result is None:
        return jsonify({'success': False, 'message': 'Operations analysis failed'}), 500

    return jsonify({'success': True, 'data': result})

@analytics_bp.route('/support-insights', methods=['GET'])
def support_insights():
    """Infer repeat purchase and frequency patterns from data"""
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    from data_manager import load_dataset, get_column_mapping
    import pandas as pd
    import numpy as np

    df = load_dataset(dataset)
    if df is None:
        return jsonify({'success': False}), 500

    mapping = get_column_mapping(dataset)
    date_col = mapping.get('date_col')
    sales_col = mapping.get('sales_col')
    product_col = mapping.get('product_col')

    if not date_col or not sales_col:
        return jsonify({'success': False}), 500

    df[date_col] = pd.to_datetime(df[date_col])

    # Product purchase frequency
    product_freq = {}
    if product_col:
        for product in df[product_col].unique():
            pdf = df[df[product_col] == product].set_index(date_col)[sales_col]
            daily = pdf.resample('D').sum().replace(0, np.nan).dropna()
            if len(daily) > 1:
                gaps = daily.index.to_series().diff().dt.days.dropna()
                avg_gap = float(gaps.mean())
                product_freq[product] = {
                    'avg_purchase_interval_days': round(avg_gap, 1),
                    'purchase_count': len(daily),
                    'consistency_score': round(100 - (float(gaps.std()) / avg_gap * 100) if avg_gap > 0 else 0, 1)
                }

    # Top repeat products
    sorted_products = sorted(product_freq.items(), key=lambda x: x[1]['purchase_count'], reverse=True)

    # Customer satisfaction proxy: consistent purchasing = satisfaction
    high_consistency = [p for p, v in product_freq.items() if v.get('consistency_score', 0) > 60]

    # Monthly sales trend for support context
    monthly = df.set_index(date_col)[sales_col].resample('MS').sum()
    monthly_growth = []
    for i in range(1, len(monthly)):
        prev = monthly.iloc[i - 1]
        curr = monthly.iloc[i]
        if prev > 0:
            monthly_growth.append(round((curr - prev) / prev * 100, 2))

    avg_growth = round(float(np.mean(monthly_growth)), 2) if monthly_growth else 0

    return jsonify({
        'success': True,
        'data': {
            'product_frequency': {k: v for k, v in sorted_products[:10]},
            'high_consistency_products': high_consistency,
            'avg_monthly_growth': avg_growth,
            'total_products_tracked': len(product_freq),
            'most_frequent_product': sorted_products[0][0] if sorted_products else None,
            'purchase_pattern_insights': [
                f"Identified {len(high_consistency)} products with consistent purchase patterns (>60% consistency).",
                f"Average monthly sales growth across the dataset: {avg_growth}%.",
                f"The most frequently purchased product is '{sorted_products[0][0]}' with {sorted_products[0][1]['purchase_count']} active purchase days." if sorted_products else "Insufficient data for frequency analysis."
            ]
        }
    })
