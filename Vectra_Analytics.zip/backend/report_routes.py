from flask import Blueprint, request, jsonify, send_file
from database import verify_token
from ml_engine import (
    prepare_time_series, run_arima_forecast, detect_anomalies,
    compute_growth_metrics, compute_product_comparison, compute_financial_analysis
)
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor, black, white
from reportlab.lib.units import inch
from reportlab.platypus import Image as RLImage
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import os
import tempfile
import numpy as np
from datetime import datetime

report_bp = Blueprint('report', __name__)

def require_auth():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        payload = verify_token(auth_header[7:])
        if payload:
            return payload
    return None

DARK_BG = HexColor('#1a1f2e')
ACCENT = HexColor('#4f81bd')
LIGHT_BG = HexColor('#f0f4f8')
TEXT_DARK = HexColor('#1F1F1F')
TEXT_GRAY = HexColor('#3A3A3A')
BORDER_COLOR = HexColor('#DADADA')
GREEN = HexColor('#27ae60')
RED = HexColor('#e74c3c')

def generate_report_content(dataset):
    """Generate full analytical report content using ML outputs"""
    # Gather all data for entire dataset (no product filtering)
    ts = prepare_time_series(dataset, product='All', period='month')
    metrics = {}
    forecast_data = {}
    anomalies = []
    products_data = []
    financial = {}

    if ts is not None and 'sales' in ts.columns:
        metrics = compute_growth_metrics(ts['sales'])
        forecast, order, _ = run_arima_forecast(ts['sales'], steps=6)
        forecast_data = {
            'values': [round(float(v), 2) for v in forecast],
            'order': order
        }
        anomalies = detect_anomalies(ts['sales'])

    products_data = compute_product_comparison(dataset)
    financial = compute_financial_analysis(dataset, product='All')

    return metrics, forecast_data, anomalies, products_data, financial, ts

def write_report_pdf(filepath, dataset):
    """Write the full PDF report"""
    metrics, forecast_data, anomalies, products_data, financial, ts = generate_report_content(dataset)

    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        rightMargin=0.7 * inch,
        leftMargin=0.7 * inch,
        topMargin=0.6 * inch,
        bottomMargin=0.6 * inch
    )

    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Title'],
        fontSize=24,
        textColor=ACCENT,
        spaceAfter=6,
        alignment=TA_LEFT,
        fontName='Helvetica-Bold'
    )
    subtitle_style = ParagraphStyle(
        'Subtitle',
        parent=styles['Normal'],
        fontSize=11,
        textColor=TEXT_GRAY,
        spaceAfter=20,
        fontName='Helvetica'
    )
    section_style = ParagraphStyle(
        'SectionHead',
        parent=styles['Heading1'],
        fontSize=16,
        textColor=ACCENT,
        spaceBefore=16,
        spaceAfter=8,
        fontName='Helvetica-Bold',
        borderWidth=0,
        borderColor=ACCENT,
        borderPadding=4
    )
    subsection_style = ParagraphStyle(
        'SubSection',
        parent=styles['Heading2'],
        fontSize=13,
        textColor=TEXT_DARK,
        spaceBefore=12,
        spaceAfter=6,
        fontName='Helvetica-Bold'
    )
    body_style = ParagraphStyle(
        'BodyText2',
        parent=styles['Normal'],
        fontSize=10,
        textColor=TEXT_DARK,
        spaceAfter=8,
        leading=14,
        fontName='Helvetica'
    )
    highlight_style = ParagraphStyle(
        'Highlight',
        parent=styles['Normal'],
        fontSize=10,
        textColor=HexColor('#2c3e50'),
        spaceAfter=8,
        leading=14,
        fontName='Helvetica-Oblique',
        backColor=HexColor('#eef2f7'),
        borderWidth=1,
        borderColor=HexColor('#cdd8e8'),
        borderRadius=4,
        borderPadding=8
    )

    story = []

    # === COVER ===
    story.append(Spacer(1, 40))
    story.append(Paragraph("VECTRA ANALYTICS", title_style))
    story.append(Paragraph("AI Business Intelligence Report", subtitle_style))
    story.append(Paragraph(f"Dataset: {dataset.replace('_', ' ').title()} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", subtitle_style))
    story.append(Spacer(1, 10))

    # Divider line via table
    divider_data = [['', '', '']]
    divider_table = Table(divider_data, colWidths=[doc.width])
    divider_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), ACCENT),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
    ]))
    story.append(divider_table)
    story.append(Spacer(1, 20))

    # === EXECUTIVE SUMMARY ===
    story.append(Paragraph("1. Executive Summary", section_style))

    total_sales = metrics.get('total', 0)
    growth = metrics.get('growth_rate', 0)
    trend = metrics.get('trend_direction', 'neutral')
    trend_change = metrics.get('trend_change', 0)

    story.append(Paragraph(
        f"This report presents a comprehensive analysis of the <b>{dataset.replace('_', ' ').title()}</b> dataset "
        f"across all products. The analysis leverages ARIMA time-series "
        f"forecasting, statistical anomaly detection, and multi-dimensional financial modeling to deliver actionable insights.",
        body_style
    ))
    story.append(Paragraph(
        f"Total sales recorded across the analysis period amount to <b>${total_sales:,.2f}</b>, with a period-over-period "
        f"growth rate of <b>{growth}%</b>. The overall trend is <b>{trend}</b>, and the half-period comparison shows a "
        f"{trend_change}% {'improvement' if trend_change > 0 else 'decline'}. These metrics form the foundation for the "
        f"strategic recommendations outlined in this report.",
        body_style
    ))

    # === KEY METRICS TABLE ===
    story.append(Paragraph("2. Key Performance Metrics", section_style))

    kpi_data = [
        ['Metric', 'Value', 'Interpretation'],
        ['Total Sales', f"${metrics.get('total', 0):,.2f}", 'Aggregate revenue across all periods'],
        ['Average Monthly Sales', f"${metrics.get('average', 0):,.2f}", 'Mean monthly revenue baseline'],
        ['Latest Period Sales', f"${metrics.get('latest', 0):,.2f}", 'Most recent period performance'],
        ['Growth Rate (MoM)', f"{metrics.get('growth_rate', 0)}%", 'Month-over-month change'],
        ['Trend Direction', metrics.get('trend_direction', 'N/A').capitalize(), 'Linear regression slope direction'],
        ['R-Squared', str(metrics.get('r_squared', 0)), 'Model fit / predictability'],
        ['Volatility (CV)', f"{metrics.get('coefficient_of_variation', 0)}%", 'Coefficient of variation'],
        ['Half-Period Trend', f"{metrics.get('trend_change', 0)}%", 'First half vs second half comparison'],
        ['Std Deviation', f"${metrics.get('std_deviation', 0):,.2f}", 'Sales variability measure'],
    ]

    col_widths = [2.2 * inch, 1.5 * inch, 3.3 * inch]
    kpi_table = Table(kpi_data, colWidths=col_widths)
    kpi_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), ACCENT),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('BACKGROUND', (0, 1), (-1, -1), HexColor('#fafbfc')),
        ('TEXTCOLOR', (0, 1), (-1, -1), TEXT_DARK),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 1), (0, -1), 'LEFT'),
        ('ALIGN', (1, 1), (1, -1), 'CENTER'),
        ('ALIGN', (2, 1), (2, -1), 'LEFT'),
        ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#ffffff'), HexColor('#f5f6f7')]),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(kpi_table)
    story.append(Spacer(1, 16))

    # === FORECASTING SECTION ===
    story.append(Paragraph("3. AI Forecasting Analysis", section_style))

    if forecast_data:
        order = forecast_data.get('order', (1, 1, 1))
        forecast_values = forecast_data.get('values', [])
        story.append(Paragraph(
            f"The forecasting engine employs an <b>ARIMA({order[0]},{order[1]},{order[2]})</b> model, automatically selected "
            f"via AIC minimization across candidate parameter combinations. The model was trained on the full multi-year historical "
            f"dataset to capture both trend and seasonal components.",
            body_style
        ))

        avg_forecast = round(np.mean(forecast_values), 2) if forecast_values else 0
        avg_hist = round(float(np.mean([metrics.get('latest', 0), metrics.get('average', 0)])), 2)
        forecast_change = round((avg_forecast - avg_hist) / avg_hist * 100, 2) if avg_hist != 0 else 0

        story.append(Paragraph(
            f"The 6-month forecast projects an average monthly value of <b>${avg_forecast:,.2f}</b>, representing a "
            f"{forecast_change}% {'increase' if forecast_change > 0 else 'decrease'} from the recent baseline. "
            f"This projection accounts for the detected {trend} trend and historical volatility patterns.",
            body_style
        ))

        # Forecast table
        forecast_header = ['Month'] + [f'Month {i+1}' for i in range(len(forecast_values))]
        forecast_row = ['Projected Sales'] + [f"${v:,.2f}" for v in forecast_values]
        forecast_table_data = [forecast_header, forecast_row]

        ft = Table(forecast_table_data)
        ft.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), ACCENT),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BACKGROUND', (0, 1), (-1, 1), HexColor('#f0f4f8')),
            ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(ft)
        story.append(Spacer(1, 12))

    # === ANOMALY DETECTION ===
    story.append(Paragraph("4. Anomaly Detection Report", section_style))

    if anomalies:
        story.append(Paragraph(
            f"Statistical anomaly detection identified <b>{len(anomalies)} significant anomalies</b> using a combined "
            f"Z-score (threshold > 2.5 standard deviations) and IQR method. Each anomaly represents a statistically "
            f"significant deviation from the historical mean.",
            body_style
        ))

        anom_header = ['Date', 'Type', 'Value', 'Mean', 'Z-Score', 'Deviation']
        anom_rows = []
        for a in anomalies[:8]:  # Limit to 8 for space
            anom_rows.append([
                a['date'],
                a['type'].capitalize(),
                f"${a['value']:,.2f}",
                f"${a['mean']:,.2f}",
                str(a['z_score']),
                f"{a['deviation_pct']}%"
            ])

        anom_table_data = [anom_header] + anom_rows
        anom_col_widths = [1.2 * inch, 0.8 * inch, 1.1 * inch, 1.1 * inch, 0.9 * inch, 1 * inch]
        at = Table(anom_table_data, colWidths=anom_col_widths)
        at.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), ACCENT),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#ffffff'), HexColor('#fff5f5')]),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(at)
        story.append(Spacer(1, 8))
        story.append(Paragraph(
            f"<i>Note: Anomalies are detected using dual-method validation (Z-score + IQR). "
            f"Spikes may indicate promotional events; drops may indicate operational disruptions or seasonal effects.</i>",
            ParagraphStyle('italic_note', parent=styles['Normal'], fontSize=8, textColor=TEXT_GRAY, fontName='Helvetica-Oblique')
        ))
    else:
        story.append(Paragraph("No statistically significant anomalies were detected in the dataset.", body_style))

    story.append(PageBreak())

    # === PRODUCT ANALYSIS ===
    story.append(Paragraph("5. Product Performance Analysis", section_style))

    if products_data:
        story.append(Paragraph(
            f"The following table presents a comparative analysis across <b>{len(products_data)} products</b>, "
            f"ranked by total sales. Profit margins and trend directions are computed from the full dataset.",
            body_style
        ))

        prod_header = ['Rank', 'Product', 'Total Sales', 'Avg Sales', 'Profit', 'Margin %', 'Trend']
        prod_rows = []
        for i, p in enumerate(products_data[:10]):
            prod_rows.append([
                str(i + 1),
                p['product'],
                f"${p['total_sales']:,.2f}",
                f"${p['average_sales']:,.2f}",
                f"${p['profit']:,.2f}",
                f"{p['margin_pct']}%",
                p['trend'].capitalize()
            ])

        prod_table_data = [prod_header] + prod_rows
        prod_col_widths = [0.5 * inch, 1.2 * inch, 1.1 * inch, 1 * inch, 1 * inch, 0.9 * inch, 0.8 * inch]
        pt = Table(prod_table_data, colWidths=prod_col_widths)
        pt.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), ACCENT),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#ffffff'), HexColor('#f5f6f7')]),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(pt)
        story.append(Spacer(1, 16))

    # === FINANCIAL ANALYSIS ===
    story.append(Paragraph("6. Financial Risk Assessment", section_style))

    if financial and 'risk_metrics' in financial:
        risk = financial['risk_metrics']
        story.append(Paragraph(
            f"Financial risk analysis was conducted using monthly profit volatility, Value at Risk (VaR), "
            f"and drawdown metrics. The current risk level is assessed as <b>{risk['risk_level']}</b>.",
            body_style
        ))

        risk_data = [
            ['Risk Metric', 'Value'],
            ['Risk Level', risk['risk_level']],
            ['Profit Volatility', f"${risk['volatility']:,.2f}"],
            ['Mean Monthly Profit', f"${risk['mean_profit']:,.2f}"],
            ['Value at Risk (95%)', f"${risk['var_95']:,.2f}"],
            ['Max Drawdown', f"${risk['max_drawdown']:,.2f}"],
            ['Sharpe-like Ratio', str(risk['sharpe_like_ratio'])],
        ]

        risk_table = Table(risk_data, colWidths=[2.5 * inch, 2 * inch])
        risk_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), ACCENT),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (1, 1), (1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#ffffff'), HexColor('#f5f6f7')]),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ]))
        story.append(risk_table)
        story.append(Spacer(1, 12))

    # === RECOMMENDATIONS ===
    story.append(Paragraph("7. Strategic Recommendations", section_style))

    recs = []
    if metrics.get('growth_rate', 0) < 0:
        recs.append("Implement targeted promotional campaigns to reverse the declining sales trend. Consider seasonal marketing strategies aligned with historical peak periods.")
    if metrics.get('coefficient_of_variation', 0) > 40:
        recs.append("Address high sales volatility through demand forecasting-driven inventory management and diversified product offerings.")
    if products_data:
        low_margin = [p for p in products_data if p['margin_pct'] < 25]
        if low_margin:
            recs.append(f"Review pricing strategy for {', '.join(p['product'] for p in low_margin[:3])} — these products show margins below 25% and may require cost optimization or price adjustment.")
    if financial and 'risk_metrics' in financial and financial['risk_metrics']['risk_level'] == 'High':
        recs.append("Financial risk is elevated. Implement cash flow buffering strategies and consider revenue diversification to mitigate VaR exposure.")
    if anomalies:
        recs.append(f"Investigate the {len(anomalies)} detected anomalies — particularly promotional spikes — to establish repeatable high-performance campaigns.")
    if not recs:
        recs.append("Current business metrics are within healthy ranges. Continue monitoring trends and maintain existing operational strategies.")

    for i, rec in enumerate(recs):
        story.append(Paragraph(f"<b>{i+1}.</b> {rec}", body_style))
        story.append(Spacer(1, 4))

    # === METHODOLOGY ===
    story.append(Spacer(1, 16))
    story.append(Paragraph("8. Methodology & Model Details", section_style))
    story.append(Paragraph(
        "This report was generated using real machine-learning models and statistical methods: "
        "<b>ARIMA</b> (Auto-Regressive Integrated Moving Average) for time-series forecasting with automatic "
        "parameter selection via AIC; <b>Z-score</b> and <b>IQR-based</b> anomaly detection for identifying "
        "statistical outliers; <b>Linear Regression</b> for trend analysis; and <b>Exponential Smoothing</b> as a "
        "fallback for short time-series. All computations are performed dynamically on the selected dataset.",
        body_style
    ))

    # === FOOTER ===
    story.append(Spacer(1, 30))
    story.append(Paragraph(
        f"<i>Report generated by Vectra Analytics AI Platform | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
        f"All data and forecasts are computed dynamically. Past performance is not indicative of future results.</i>",
        ParagraphStyle('footer', parent=styles['Normal'], fontSize=8, textColor=TEXT_GRAY, fontName='Helvetica-Oblique', alignment=TA_CENTER)
    ))

    doc.build(story)

@report_bp.route('/generate', methods=['GET'])
def generate_report():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')

    try:
        # Create temp file
        fd, filepath = tempfile.mkstemp(suffix='.pdf', prefix='vectra_report_')
        os.close(fd)

        write_report_pdf(filepath, dataset)

        filename = f"Vectra_Report_{dataset}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
        return send_file(filepath, as_attachment=True, download_name=filename, mimetype='application/pdf')
    except Exception as e:
        return jsonify({'success': False, 'message': f'Report generation failed: {str(e)}'}), 500
