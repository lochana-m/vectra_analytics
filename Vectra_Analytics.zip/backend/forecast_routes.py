from flask import Blueprint, request, jsonify
from database import verify_token
from ml_engine import (
    prepare_time_series, run_arima_forecast, detect_anomalies,
    compute_growth_metrics, simulate_scenario
)
import numpy as np

forecast_bp = Blueprint('forecast', __name__)

def require_auth():
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        payload = verify_token(auth_header[7:])
        if payload:
            return payload
    return None

def generate_ai_forecast_explanation(metrics, forecast_values, historical_values):
    """Generate multi-paragraph AI explanation from real statistics"""
    explanation_parts = []

    # Part 1: Current state analysis
    trend_word = "upward" if metrics.get('trend_direction') == 'upward' else "downward"
    explanation_parts.append(
        f"Based on statistical analysis of the historical data, the current sales trajectory shows a clear {trend_word} trend "
        f"with a slope of {metrics.get('trend_slope', 0)} per period. The R-squared value of {metrics.get('r_squared', 0)} indicates "
        f"{'strong' if metrics.get('r_squared', 0) > 0.6 else 'moderate' if metrics.get('r_squared', 0) > 0.3 else 'weak'} "
        f"predictability in the data pattern."
    )

    # Part 2: Growth analysis
    growth = metrics.get('growth_rate', 0)
    trend_change = metrics.get('trend_change', 0)
    explanation_parts.append(
        f"The most recent period recorded a growth rate of {growth}% compared to the previous period. "
        f"Comparing the first half to the second half of the dataset reveals a {trend_change}% {'improvement' if trend_change > 0 else 'decline'}, "
        f"suggesting {'accelerating' if trend_change > 0 else 'decelerating'} momentum in the business cycle. "
        f"The coefficient of variation stands at {metrics.get('coefficient_of_variation', 0)}%, "
        f"indicating {'high' if metrics.get('coefficient_of_variation', 0) > 40 else 'moderate' if metrics.get('coefficient_of_variation', 0) > 20 else 'low'} volatility."
    )

    # Part 3: Forecast outlook
    if len(forecast_values) > 0:
        avg_forecast = round(np.mean(forecast_values), 2)
        avg_historical = round(np.mean(historical_values[-6:]) if len(historical_values) >= 6 else np.mean(historical_values), 2)
        forecast_change = round((avg_forecast - avg_historical) / avg_historical * 100, 2) if avg_historical != 0 else 0
        explanation_parts.append(
            f"The ARIMA model forecasts an average value of {avg_forecast} over the next {len(forecast_values)} periods, "
            f"representing a {forecast_change}% {'increase' if forecast_change > 0 else 'decrease'} from recent averages. "
            f"The model was trained on the full historical dataset spanning multiple years to ensure robust predictions. "
            f"Key risk factors include seasonal fluctuations and market volatility detected in the variance analysis."
        )

    return "\n\n".join(explanation_parts)

@forecast_bp.route('/predict', methods=['GET'])
def predict():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    product = request.args.get('product', 'All')
    period = request.args.get('period', 'month')
    steps = int(request.args.get('steps', 6))

    ts = prepare_time_series(dataset, product=product, period=period)
    if ts is None or 'sales' not in ts.columns:
        return jsonify({'success': False, 'message': 'Insufficient data for forecasting'}), 500

    sales_series = ts['sales']
    forecast, order, _ = run_arima_forecast(sales_series, steps=steps)

    metrics = compute_growth_metrics(sales_series)
    explanation = generate_ai_forecast_explanation(
        metrics, forecast.tolist(), sales_series.values.tolist()
    )

    # Generate future dates
    import pandas as pd
    last_date = sales_series.index[-1]
    if period == 'month':
        future_dates = pd.date_range(start=last_date, periods=steps + 1, freq='MS')[1:]
    elif period == 'week':
        future_dates = pd.date_range(start=last_date, periods=steps + 1, freq='W')[1:]
    elif period == 'year':
        future_dates = pd.date_range(start=last_date, periods=steps + 1, freq='YS')[1:]
    else:
        future_dates = pd.date_range(start=last_date, periods=steps + 1, freq='D')[1:]

    return jsonify({
        'success': True,
        'historical': {
            'dates': [d.strftime('%Y-%m-%d') for d in sales_series.index],
            'values': [round(float(v), 2) for v in sales_series.values]
        },
        'forecast': {
            'dates': [d.strftime('%Y-%m-%d') for d in future_dates],
            'values': [round(float(v), 2) for v in forecast]
        },
        'model_order': order,
        'metrics': metrics,
        'ai_explanation': explanation
    })

@forecast_bp.route('/anomalies', methods=['GET'])
def anomalies():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    dataset = request.args.get('dataset', 'uk_ecommerce')
    product = request.args.get('product', 'All')
    period = request.args.get('period', 'month')

    ts = prepare_time_series(dataset, product=product, period=period)
    if ts is None or 'sales' not in ts.columns:
        return jsonify({'success': False, 'message': 'No data'}), 500

    anomaly_list = detect_anomalies(ts['sales'])
    return jsonify({
        'success': True,
        'anomalies': anomaly_list,
        'total_count': len(anomaly_list)
    })

@forecast_bp.route('/simulate', methods=['POST'])
def simulate():
    auth = require_auth()
    if not auth:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401

    data = request.get_json()
    dataset = data.get('dataset', 'uk_ecommerce')
    product = data.get('product', 'All')
    change_pct = data.get('change_pct', 10)
    periods = data.get('periods', 6)

    result = simulate_scenario(dataset, product, change_pct, periods)
    if result is None:
        return jsonify({'success': False, 'message': 'Simulation failed'}), 500

    return jsonify({'success': True, 'simulation': result})
