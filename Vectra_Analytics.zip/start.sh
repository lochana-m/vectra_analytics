#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

clear

echo "============================================================"
echo "    VECTRA ANALYTICS - AI Business Intelligence Platform"
echo "============================================================"
echo

# Detect Python
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    echo "[ERROR] Python 3.9+ is required but not found"
    echo
    echo "Please install Python from:"
    echo "  macOS: brew install python3"
    echo "  Ubuntu/Debian: sudo apt-get install python3 python3-pip"
    echo "  Other: https://www.python.org/downloads/"
    exit 1
fi

echo "[OK] Python found: $($PYTHON --version)"

# Check pip
if ! $PYTHON -m pip --version &> /dev/null; then
    echo "[ERROR] pip is not available"
    exit 1
fi

echo "[OK] pip found"
echo

# Install dependencies
echo "[STEP 1/4] Installing Python dependencies..."
echo "This may take a few minutes on first run..."
cd backend
$PYTHON -m pip install -r requirements.txt --quiet --disable-pip-version-check
if [ $? -ne 0 ]; then
    echo
    echo "[ERROR] Failed to install dependencies"
    echo
    echo "Try running manually:"
    echo "  cd backend"
    echo "  $PYTHON -m pip install -r requirements.txt"
    exit 1
fi
cd ..

echo "[OK] Dependencies installed"
echo

# Kill existing processes
echo "[STEP 2/4] Checking for port conflicts..."
lsof -ti:5000 | xargs kill -9 2>/dev/null || true
lsof -ti:8080 | xargs kill -9 2>/dev/null || true
echo "[OK] Ports ready"
echo

# Start backend
echo "[STEP 3/4] Starting backend server..."
cd backend
$PYTHON app.py > backend.log 2>&1 &
BACKEND_PID=$!
cd ..

# Wait and check backend
echo "Waiting for backend to initialize..."
sleep 5

if curl -s http://localhost:5000/api/health > /dev/null 2>&1; then
    echo "[OK] Backend running on http://localhost:5000 (PID: $BACKEND_PID)"
else
    echo "[WARNING] Backend may not have started properly"
    echo "Check backend/backend.log for errors"
fi
echo

# Start frontend
echo "[STEP 4/4] Starting frontend server..."
cd frontend
$PYTHON -m http.server 8080 > frontend.log 2>&1 &
FRONTEND_PID=$!
cd ..

sleep 2

echo
echo "============================================================"
echo " VECTRA ANALYTICS IS NOW RUNNING"
echo "============================================================"
echo
echo "  Frontend:  http://localhost:8080"
echo "  Backend:   http://localhost:5000/api"
echo
echo "  Backend PID:  $BACKEND_PID"
echo "  Frontend PID: $FRONTEND_PID"
echo
echo "  Opening browser..."
echo

# Open browser
if command -v open &> /dev/null; then
    open http://localhost:8080
elif command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:8080
fi

echo "============================================================"
echo
echo " To stop servers:"
echo "   kill $BACKEND_PID $FRONTEND_PID"
echo
echo " Or press Ctrl+C to stop all"
echo
echo "============================================================"
echo

# Cleanup function
cleanup() {
    echo
    echo "Stopping servers..."
    kill $BACKEND_PID $FRONTEND_PID 2>/dev/null
    echo "Servers stopped"
    exit 0
}

trap cleanup INT TERM

# Keep script running
wait
