# Vectra Analytics – AI Business Intelligence Platform

## 🚀 QUICK START

### Windows
1. Extract the ZIP file
2. **Double-click `start.bat`**
3. Wait for browser to open automatically
4. Default login: Create an account via Sign Up tab

### macOS / Linux
1. Extract the ZIP file
2. Open terminal in the extracted folder
3. Run:
   ```bash
   chmod +x start.sh
   ./start.sh
   ```
4. Browser opens automatically

---

## ✅ REQUIREMENTS

- **Python 3.9, 3.10, 3.11, or 3.12** (required)
- **pip** (usually comes with Python)
- Modern web browser (Chrome, Firefox, Edge, Safari)
- **Windows**: No additional requirements
- **macOS/Linux**: May need `lsof` and `curl` (usually pre-installed)

### How to Check Python Version
```bash
python --version
# or
python3 --version
```

If Python is not installed:
- **Windows**: Download from https://python.org (check "Add Python to PATH")
- **macOS**: `brew install python3`
- **Linux**: `sudo apt-get install python3 python3-pip`

---

## 🌐 ACCESSING THE APPLICATION

Once started, the application will be available at:
- **Frontend**: http://localhost:8080
- **Backend API**: http://localhost:5000/api
- **Health Check**: http://localhost:5000/api/health

---

## 🔧 TROUBLESHOOTING

### Problem: "Python is not installed or not in PATH"

**Solution:**
1. Install Python 3.9+ from https://python.org
2. **Windows**: During installation, CHECK the box "Add Python to PATH"
3. Restart your terminal/command prompt
4. Verify: `python --version`

### Problem: "Port 5000 or 8080 already in use"

**Solution (Windows):**
```batch
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F

netstat -ano | findstr :8080
taskkill /PID <PID_NUMBER> /F
```

**Solution (macOS/Linux):**
```bash
lsof -ti:5000 | xargs kill -9
lsof -ti:8080 | xargs kill -9
```

### Problem: "Failed to install dependencies"

**Solution:**
```bash
cd backend
pip install -r requirements.txt --upgrade
# or
python -m pip install -r requirements.txt --upgrade
```

If still failing, install individually:
```bash
pip install flask flask-cors pandas numpy scikit-learn statsmodels scipy reportlab PyJWT bcrypt
```

### Problem: "Backend not responding" or "Cannot reach page"

**Check if backend started:**
```bash
curl http://localhost:5000/api/health
```

If no response:
1. Check `backend/backend.log` for errors
2. Try running backend manually:
   ```bash
   cd backend
   python app.py
   ```
3. Look for error messages in the console

**Common fixes:**
- Ensure all dependencies installed: `pip install -r requirements.txt`
- Check firewall isn't blocking ports 5000/8080
- Try different Python version (3.9-3.12 supported)

### Problem: Frontend shows but charts don't load

**Solution:**
1. Open browser console (F12)
2. Check for CORS errors
3. Ensure backend is running (check health endpoint)
4. Clear browser cache (Ctrl+Shift+Del)
5. Try a different browser

### Problem: "Module not found" errors

**Solution:**
```bash
cd backend
pip install --upgrade pip
pip install -r requirements.txt --force-reinstall
```

---

## 📊 FEATURES OVERVIEW

### Dashboards
1. **Main Dashboard** — Sales trends, forecasts, anomaly detection
2. **Executive Dashboard** — Product comparison, scenario simulation
3. **Sales Dashboard** — Daily sales, last 7 days breakdown
4. **Support Dashboard** — Purchase frequency, retention patterns
5. **Financial Dashboard** — Revenue, profit, risk analysis
6. **Operations Dashboard** — Transaction timing, bottleneck detection
7. **Reports Dashboard** — Generate AI-written PDF reports
8. **Upload Dataset** — Upload custom CSV files

### Demo Datasets
- **UK Ecommerce** — 2 years, 10 products, seasonal patterns
- **Walmart** — 2.5 years, 10 categories, 50 stores
- **Rossmann** — 1.5 years, drugstore products with promotional spikes

### AI Features
- **ARIMA Forecasting** — Real time-series prediction (not fake)
- **Anomaly Detection** — Z-score + IQR statistical methods
- **AI Chatbot** — Natural language query processing
- **PDF Reports** — Professional multi-section reports
- **Smart Analytics** — Growth, trends, risk metrics

---

## 🎨 UI FEATURES

- **Glassmorphism Design** — Professional, modern interface
- **Dark/Light Mode** — Toggle in top-right
- **USD ↔ INR Currency** — Real-time conversion for all values
- **Collapsible Sidebar** — More screen space
- **Interactive Charts** — Hover tooltips, export as image, legend toggle
- **Responsive Layout** — Works on desktop, tablet, mobile

---

## 📁 PROJECT STRUCTURE

```
vectra/
├── start.bat              # Windows launcher
├── start.sh               # Unix/Mac launcher
├── README.md              # This file
├── backend/
│   ├── app.py             # Flask server
│   ├── requirements.txt   # Python dependencies
│   ├── database.py        # User authentication
│   ├── auth_routes.py     # Login/signup endpoints
│   ├── data_manager.py    # Dataset handling
│   ├── data_routes.py     # Data API
│   ├── ml_engine.py       # Machine learning models
│   ├── analytics_routes.py
│   ├── forecast_routes.py
│   ├── chatbot_routes.py
│   ├── report_routes.py
│   └── upload_routes.py
└── frontend/
    └── index.html         # Complete SPA application
```

---

## 🔐 AUTHENTICATION

### First Time Setup
1. Open http://localhost:8080
2. Click "Sign Up" tab
3. Enter name, email, password
4. Click "Create Account"
5. You're logged in automatically

### Forgot Password (Demo Mode)
1. Click "Reset" tab
2. Enter your email
3. Reset token will appear on screen
4. Enter new password
5. Click "Reset Password"

**Note**: In production, the reset token would be emailed. For demo, it's shown directly.

---

## 🧪 TESTING THE APPLICATION

### Test Authentication
1. Sign up with any email (e.g., test@example.com)
2. Password must be 6+ characters
3. Log out and log back in

### Test Dashboards
1. Navigate through all 8 dashboards using left sidebar
2. Change dataset from dropdown in top bar
3. Toggle USD/INR currency
4. Switch between light/dark mode

### Test ML Features
1. **Forecasting**: Go to Main Dashboard, view AI Forecast panel
2. **Anomalies**: Scroll to Anomaly Detection section
3. **Chatbot**: Click floating button (bottom-left), ask "What is the forecast?"
4. **Reports**: Go to Reports page, generate PDF

### Test Upload
1. Create a simple CSV:
   ```csv
   Date,Product,Sales
   2024-01-01,Widget,1000
   2024-01-02,Widget,1200
   2024-01-03,Widget,980
   ```
2. Go to Upload Dataset page
3. Drag & drop the CSV
4. Verify quality report
5. Dataset appears in dropdown

---

## 🛑 STOPPING THE APPLICATION

### Windows
1. Close the command prompt window, OR
2. Press Ctrl+C in the terminal, OR
3. Open Task Manager → End `python.exe` processes

### macOS / Linux
1. Press Ctrl+C in the terminal, OR
2. Run: `lsof -ti:5000 -ti:8080 | xargs kill -9`

---

## ⚙️ TECHNICAL DETAILS

### Backend
- **Framework**: Flask 3.0
- **Authentication**: JWT tokens + bcrypt password hashing
- **ML Models**: 
  - ARIMA (statsmodels)
  - Exponential Smoothing
  - Z-score anomaly detection
  - IQR outlier detection
  - Linear regression for trends
- **PDF Generation**: ReportLab
- **Data Processing**: pandas, numpy

### Frontend
- **Type**: Single-Page Application (vanilla JS)
- **Charts**: Chart.js 4.4
- **Icons**: Font Awesome 6.4
- **No frameworks**: Pure HTML/CSS/JS
- **Responsive**: CSS Grid + Flexbox

---

## 📞 SUPPORT

### Common Issues

**Charts not showing?**
- Check browser console (F12) for errors
- Verify backend is running: http://localhost:5000/api/health
- Try clearing cache

**Login not working?**
- Verify backend logs for errors
- Check `backend/backend.log`
- Ensure JWT and bcrypt installed

**PDF export fails?**
- Ensure reportlab installed: `pip install reportlab`
- Check disk space
- Try a different browser

---

## 📄 LICENSE

This is a demo application for educational and evaluation purposes.

---

**Enjoy using Vectra Analytics! 🚀**
