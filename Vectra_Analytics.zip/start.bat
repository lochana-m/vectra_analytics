@echo off
title Vectra Analytics - Starting...
color 0B
cls

echo ============================================================
echo     VECTRA ANALYTICS - AI Business Intelligence Platform
echo ============================================================
echo.

rem Check Python
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python is not installed or not in PATH
    echo.
    echo Please install Python 3.9 or higher from:
    echo https://www.python.org/downloads/
    echo.
    echo Make sure to check "Add Python to PATH" during installation
    pause
    exit /b 1
)

echo [OK] Python found
python --version

rem Check pip
pip --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] pip is not available
    pause
    exit /b 1
)

echo [OK] pip found
echo.

rem Navigate to script directory
cd /d "%~dp0"

rem Install dependencies
echo [STEP 1/4] Installing Python dependencies...
echo This may take a few minutes on first run...
cd backend
pip install -r requirements.txt --quiet --disable-pip-version-check
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Failed to install dependencies
    echo.
    echo Try running manually:
    echo   cd backend
    echo   pip install -r requirements.txt
    pause
    exit /b 1
)
cd ..

echo [OK] Dependencies installed
echo.

rem Kill any existing processes on ports 5000 and 8080
echo [STEP 2/4] Checking for port conflicts...
for /f "tokens=5" %%a in ('netstat -aon ^| find ":5000" ^| find "LISTENING"') do taskkill /F /PID %%a >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| find ":8080" ^| find "LISTENING"') do taskkill /F /PID %%a >nul 2>&1
echo [OK] Ports ready
echo.

rem Start backend
echo [STEP 3/4] Starting backend server...
cd backend
start /B python app.py
cd ..

rem Wait for backend
echo Waiting for backend to initialize...
timeout /t 5 /nobreak >nul

rem Check if backend started
curl -s http://localhost:5000/api/health >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [WARNING] Backend may not have started properly
    echo If you see errors, check backend\backend.log
    echo.
) else (
    echo [OK] Backend running on http://localhost:5000
)
echo.

rem Start frontend
echo [STEP 4/4] Starting frontend server...
cd frontend
start /B python -m http.server 8080
cd ..

rem Wait for frontend
timeout /t 3 /nobreak >nul

echo.
echo ============================================================
echo  VECTRA ANALYTICS IS NOW RUNNING
echo ============================================================
echo.
echo  Frontend:  http://localhost:8080
echo  Backend:   http://localhost:5000/api
echo.
echo  Opening browser...
echo.

rem Open browser
start http://localhost:8080

echo ============================================================
echo.
echo  To stop the servers:
echo  1. Close this window
echo  2. Open Task Manager (Ctrl+Shift+Esc)
echo  3. End these processes:
echo     - python.exe (app.py)
echo     - python.exe (http.server)
echo.
echo  Or run: taskkill /F /IM python.exe
echo.
echo ============================================================
echo.
echo Press any key to view server logs (servers keep running)...
pause >nul

echo.
echo === BACKEND LOG ===
type backend\backend.log 2>nul
echo.
echo === FRONTEND LOG ===
type frontend\frontend.log 2>nul
echo.
pause
